
# TradingBot Backend

## Setup

1. Copiar `.env` e ajustar variáveis.
2. Build com Docker:

```bash
docker-compose up --build
```

3. API estará disponível em http://localhost:8000/docs

Endpoints principais:
- Registro de Usuário
- Login JWT
- Estatísticas de Trades
- Exportação CSV
- Configuração de Alertas
