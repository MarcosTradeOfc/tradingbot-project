import React from "react";

const ToastNotification = ({ message }) => (
  <div className="fixed bottom-5 right-5 bg-green-500 text-white px-4 py-2 rounded shadow-xl">
    {message}
  </div>
);

export default ToastNotification;