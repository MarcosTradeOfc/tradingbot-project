import React from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

const Dashboard = () => (
  <div className="flex">
    <Sidebar />
    <div className="flex-1">
      <Navbar />
      <div className="p-4">
        <h2 className="text-2xl font-semibold mb-4">Estatísticas de Trading em Tempo Real</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 shadow rounded">Gráfico de PnL</div>
          <div className="bg-white p-4 shadow rounded">Distribuição de Ordens</div>
        </div>
      </div>
    </div>
  </div>
);

export default Dashboard;