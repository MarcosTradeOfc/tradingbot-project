import React from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";

const AlertsSettings = () => (
  <div className="flex">
    <Sidebar />
    <div className="flex-1">
      <Navbar />
      <div className="p-4">
        <h2 className="text-2xl font-semibold mb-4">Configurações de Alertas</h2>
        <form className="space-y-4">
          <div>
            <label>Email</label>
            <input type="email" className="w-full border rounded p-2" />
          </div>
          <div>
            <label>Telegram Chat ID</label>
            <input type="text" className="w-full border rounded p-2" />
          </div>
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Salvar</button>
        </form>
      </div>
    </div>
  </div>
);

export default AlertsSettings;