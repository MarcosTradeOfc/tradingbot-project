import React from "react";

const Login = () => (
  <div className="min-h-screen flex items-center justify-center">
    <form className="bg-white p-8 rounded shadow-md w-full max-w-sm space-y-4">
      <h2 className="text-xl font-semibold text-center">Login</h2>
      <input type="text" placeholder="Usuário" className="w-full border p-2 rounded" />
      <input type="password" placeholder="Senha" className="w-full border p-2 rounded" />
      <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded">Entrar</button>
    </form>
  </div>
);

export default Login;