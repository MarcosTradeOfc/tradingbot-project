# Backend - Trading Bot API

Estrutura baseada em FastAPI, Docker e PostgreSQL.