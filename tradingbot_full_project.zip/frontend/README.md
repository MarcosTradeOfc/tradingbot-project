# Frontend - Trading Bot Dashboard

Interface feita com React, Vite e Tailwind CSS.